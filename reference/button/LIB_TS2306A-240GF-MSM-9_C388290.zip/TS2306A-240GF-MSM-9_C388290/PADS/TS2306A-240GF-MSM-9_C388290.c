*PADS-LIBRARY-SCH-DECALS-V9*

TS2306A-240GF-MSM-9_C388290 0 0 100 10 100 10 4 4 0 2 24
TIMESTAMP 2017.12.11.10.29.14
"Default Font"
"Default Font"
450   150   0 8 100 10 "Default Font"
REF-DES
300   -100  0 12 100 10 "Default Font"
PART-TYPE
300   -200  0 12 100 10 "Default Font"
*
300   -300  0 12 100 10 "Default Font"
*
CIRCLE 2 10 0 -1
240   0    
200   0    
CIRCLE 2 10 0 -1
400   0    
360   0    
OPEN   2 10 0 -1
200   50   
400   50   
OPEN   2 10 0 -1
300   50   
300   100  
T0     0     0 0 140   20    0 2 230   0     0 16 PIN
P-520  0     0 2 -330  0     0 2 0
T600   0     0 2 140   20    0 2 230   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0

*END*
